package bull;

import java.awt.Color;

public class Mouth {
	private Color color;
	private int width, height;
	
	public Mouth(Color color, int width, int height) {
		this.color = color;
		this.width = width / 2;
		this.height = height / 20;
	}
	
	public void drawAt(int x, int y) {
		Drawing.pen().setColor(color);
		Drawing.pen().fillRect(x, y, width, height);
	}
}
