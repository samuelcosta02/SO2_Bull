package bull;

import java.awt.Color;

public class Head {
	private Color color;
	private int width, height;
	private Ear earLeft, earRight;
	private Eye eyeLeft, eyeRight;
	private Nose nose;
	private Mouth mouth;
	private Horn hornLeft, hornRight;
	
	public Head(Color color, int width, int height) {
		this.color = color;
		this.width = width / 4;
		this.height = height / 2;
		this.earLeft = new Ear(color, this.width, this.height);
		this.earRight = new Ear(color, this.width, this.height);
		this.eyeLeft = new Eye(Color.WHITE, this.width, this.height);
		this.eyeRight = new Eye(Color.WHITE, this.width, this.height);
		this.nose = new Nose(Color.PINK, this.width, this.height);
		this.mouth = new Mouth(Color.PINK, this.width, this.height);
		this.hornLeft = new Horn(Color.BLACK, this.width, this.height);
		this.hornRight = new Horn(Color.BLACK, this.width, this.height);
	}
	
	public void drawAt(int x, int y) {
		Drawing.pen().setColor(color);
		Drawing.pen().fillRect(x, y, width, height);
		earLeft.drawAt(x, y - height / 4);
		earRight.drawAt(x + width - width / 25, y - height / 4);
		eyeLeft.drawAt(x + width / 4, y + height / 5);
		eyeRight.drawAt(x + width / 2 + width / 15, y + height / 5);
		nose.drawAt(x + width / 4, y + height / 2);
		mouth.drawAt(x + width / 4, y + height / 2 + height / 3);
		hornLeft.drawAt(x + width / 4, y);
		hornRight.drawAt(x + width / 2 + width / 15, y);
	}
}